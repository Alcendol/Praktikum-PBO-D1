public interface Pajak {
    double hitungPajak();
}