import java.util.Date;

public class Petani extends Manusia implements Pajak {
    private String asal_kota;
    private static int counterPetani = 0;

    // Constructor
    public Petani(String name, Date tgl_mulai_kerja, String alamat, double pendapatan, String asal_kota) {
        super(name, tgl_mulai_kerja, alamat, pendapatan);
        this.asal_kota = asal_kota;
        counterPetani++;
    }

    // Getter dan Setter
    public String getAsal_kota() {
        return asal_kota;
    }

    public void setAsal_kota(String asal_kota) {
        this.asal_kota = asal_kota;
    }

    public static int getCounterPetani() {
        return counterPetani;
    }

    // Implementasi method hitungMasakerja
    @Override
    public int hitungMasakerja() {
        Date now = new Date();
        long diff = now.getTime() - tgl_mulai_kerja.getTime();
        int tahun = (int) (diff / (1000L * 60 * 60 * 24 * 365));
        return tahun + 1; // C = digit ke-12 NIM (1)
    }

    // Implementasi method hitungPajak
    @Override
    public double hitungPajak() {
        return 0; // Petani tidak dikenakan pajak
    }

    // Override method cetakInfo
    @Override
    public void cetakInfo() {
        super.cetakInfo();
        System.out.println("Asal Kota: " + asal_kota);
    }
}